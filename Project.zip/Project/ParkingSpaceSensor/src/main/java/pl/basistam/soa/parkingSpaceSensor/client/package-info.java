@javax.xml.bind.annotation.XmlSchema(namespace = "http://webService.main.soa.basistam.pl/")
package pl.basistam.soa.parkingSpaceSensor.client;
