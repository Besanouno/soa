package pl.basistam.soa.main;

/**
 * Created by marcin on 29.05.17.
 */
public class WrongParkingSpotNumberException extends Exception {
}
