package pl.basistam.soa.main.users;

public enum Role {
    ADMIN, INSPECTOR
}
