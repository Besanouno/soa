package pl.basistam.ejb;

public interface Converter {
    double fahr2cels(double temp);
    double cels2fahr(double temp);
}
