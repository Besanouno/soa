package pl.basistam.web;

import pl.basistam.books.Book;
import pl.basistam.ejb.Library;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Hashtable;
import java.util.List;

public class LibraryBean {
    private Library library;

    public LibraryBean() throws NamingException {
        this.library = lookupLibraryEjb();
    }

    public List<Book> getReservedBooks() {
        return library.getReservedBooks();
    }

    public List<Book> getLoanedBooks() {
        return library.getLoanedBooks();
    }

    public List<Book> getIdleBooks() {
        return library.getIdleBooks();
    }

    public void reserveBook(String id) {
        try {
            library.reserveBook(Long.parseLong(id));
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }

    public void loanBook(String id) {
        try {
            library.loanBook(Long.parseLong(id));
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }

    public void returnBook(String id) {
        try {
            library.returnBook(Long.parseLong(id));
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }

    private Library lookupLibraryEjb() throws NamingException {
        final Hashtable<String, String> jndiProperties = new Hashtable<String, String>();
        jndiProperties.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
        jndiProperties.put(InitialContext.PROVIDER_URL, "remote://localhost:4447");
        final Context context = new InitialContext(jndiProperties);
        return (Library) context.lookup("java:app/library/LibraryImpl!pl.basistam.ejb.Library");
    }
}
