package pl.basistam.books;

public interface Book {
    void setId(Long id);
    Long getId();

    void setAuthors(String authors);
    String getAuthors();

    void setTitle(String title);
    String getTitle();

    void setIsbn(String isbn);
    String getIsbn();

    void setState(State state);
    State getState();
}
