package pl.basistam.ejb;

import pl.basistam.books.Book;

import java.util.List;

public interface Library {
    void reserveBook(Long id);
    void loanBook(Long id);
    void returnBook(Long id);
    List<Book> getReservedBooks();
    List<Book> getLoanedBooks();
    List<Book> getIdleBooks();
}
