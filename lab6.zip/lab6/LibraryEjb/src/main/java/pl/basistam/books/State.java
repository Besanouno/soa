package pl.basistam.books;

public enum State
{
    IDLE, RESERVED, LOANED
}
