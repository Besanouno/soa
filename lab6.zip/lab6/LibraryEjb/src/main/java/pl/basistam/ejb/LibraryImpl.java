package pl.basistam.ejb;

import pl.basistam.books.Book;
import pl.basistam.books.BookImpl;
import pl.basistam.books.BooksRegister;
import pl.basistam.books.State;

import javax.annotation.PostConstruct;
import javax.ejb.Lock;
import javax.ejb.Remote;
import javax.ejb.Singleton;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static javax.ejb.LockType.READ;
import static javax.ejb.LockType.WRITE;

@Singleton
@Remote(Library.class)
public class LibraryImpl implements Library {
    private List<BookImpl> books;
    private BooksRegister register = new BooksRegister();

    @PostConstruct
    private void loadBooks() {
        books = register.loadBooks();
    }

    @Override
    @Lock(WRITE)
    public void reserveBook(Long id) {
        changeBookState(id, State.RESERVED);
    }

    @Override
    @Lock(WRITE)
    public void returnBook(Long id) {
        changeBookState(id, State.IDLE);
    }

    @Override
    @Lock(READ)
    public List<Book> getReservedBooks() {
        return getBooks(State.RESERVED);
    }

    @Override
    @Lock(READ)
    public List<Book> getLoanedBooks() {
        return getBooks(State.LOANED);
    }

    @Override
    @Lock(READ)
    public List<Book> getIdleBooks() {
        return getBooks(State.IDLE);
    }

    @Override
    @Lock(WRITE)
    public void loanBook(Long id) {
        changeBookState(id, State.LOANED);
    }


    private void changeBookState(Long id, State state) {
        books.stream()
                .filter(b -> Objects.equals(b.getId(), id))
                .forEach(b -> b.setState(state));
        register.saveBooks(books);
    }

    private List<Book> getBooks(State state) {
        return books.stream().filter(b -> b.getState() == state).collect(Collectors.toList());
    }

}
