package pl.basistam.books;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "books")
public class Books {
    private List<BookImpl> books;

    @XmlElement(name = "book")
    public List<BookImpl> getBooks() {
        return books;
    }

    public void setBooks(List<BookImpl> books) {
        this.books = books;
    }
}
